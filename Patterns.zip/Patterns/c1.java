class c2
{
	static int sum(int i, int j)
	{
		return i+j;	
	}
	static double sum(int i, float j)
	{
		return i+j;	
	}
	static void show(int r1)
	{
		System.out.println(res);
	}
	static void show(double r1)
	{
		System.out.println(res);
	}
}

class c1
{
	public static void main(String args[])
	{
		int r = c2.sum(11,22);
		c2.show(r1);
		double r1 = Operation.sum(11,22.3f);
		c2.show1(r1);
	}
}
